<?php  
	/**
	* 
	*/
	class Urna
	{
		var $candidato;
		var $num_candidato;
		var $votosCand;
		public function setCandidato($candidato){
			$this->candidato = $candidato;
		}
		public function getCandidato(){
			echo $this->candidato;
		}
		public function setNumCandidato($num_candidato){
			$this->num_candidato = $num_candidato;
		}
		public function getNumCandidato(){
			echo $this->num_candidato;
		}
		public function votar($voto){
			$this->votosCand += $voto;
		}
		public function exibirResultado(){
			echo $this->votosCand;
		}
		public function iniciarVotacao(){
			$this->votosCand = 0;
		}
	}
?>