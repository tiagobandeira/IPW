<!DOCTYPE html>
<html>
<head>
	<title>Exercício 06</title>
	<link rel="stylesheet" type="text/css" href="style_boot.css">
	<style type="text/css">
		.label{
			width: 100%;
			height: 35px;
			border: solid 1px #ccc;
			text-align: right;
			font-size: 30px;
			font-family: DejaVu Sans Mono;
			background: #eee;
		}
		.pannel-item-default input[type='text']{
			font-size: 20px;
		}
		.pannel-item-default {
			text-align: center;
		}
	</style>
</head>
<body>
	<?php
		#Inicia a sessão
		session_start();
		#inclui a classe urna que está em urna.php
		include_once('urna.php');
		#Instacia os candidatos com classe Urna.
		$candidato1 = new Urna();
		$candidato1->setCandidato("Mariele"); #Nome do primeiro candidato 

		$candidato2 = new Urna();
		$candidato2->setCandidato("Gabriela"); #Nome do segundo candidato
		#Verifica se as sessões existem. Se verdadeiro, os objetos recebem o valor delas. Caso contrário, são iniciadas com 0. 
		if (isset($_SESSION['voto1']) && isset($_SESSION['voto2'])) {
			$candidato1->votar($_SESSION['voto1']);	
			$candidato2->votar($_SESSION['voto2']);	
		}else{
			$_SESSION['voto1'] = 0;
			$_SESSION['voto2'] = 0;
		}
		$btn = "";# iniciar btn para evitar erros
		#Verifica se o post foi iniciado
		if (isset($_POST['btn'])) {
			$btn = $_POST['btn'];
			if ($btn == "Voto1") {
				$_SESSION['voto1'] += 1;
			}else if ($btn == "Voto2") {
				$_SESSION['voto2'] += 1;
			}else if ($btn == "Iniciar") {
				unset($_SESSION['voto1']);
				unset($_SESSION['voto2']);
			}
		}
		#session_destroy();
		
	?>
	<div class="content">
		<div class="grid">
			<div class="col-4">
				<div class="pannel">
					<div class="pannel-header orange">
						<h3 class="pannel-title" align="center">
							Votação
						</h3>
					</div>
						<div class="pannel-body" align="center">
						<form method="post" action="index.php">
							<span class="pannel-item-default">
								<h3 >Escolha seu candidato</h3>
								<?php  
									if ($btn == "Voto1") {
										echo "Votou para ";
										$candidato1->getCandidato();
									}elseif ($btn == "Voto2") {
										echo "Votou para ";
										$candidato2->getCandidato();
									}
								?>
							</span>
							<span class="pannel-item-default">
								<div class="grid">
									<div class="col-2">
										<input type="submit" name="btn"  value="Voto1" maxlength="50" placeholder="Ex. 937.00">
										<?php $candidato1->getCandidato(); ?>
									</div>
									<div class="col-2">
										
										
										<input type="submit" name="btn"  value="Voto2" maxlength="50" placeholder="Ex. 100 Watt">	
										<?php $candidato2->getCandidato(); ?>
									</div>
								</div>
							</span>
							<span class="pannel-item-default">
								<input type="submit" name="btn" value="Resultado">
								<input type="submit" name="btn" value="Iniciar">
							</span>
						</form>
						<span class="pannel-item-default">
							<h3>Votos</h3>
							<?php if ($btn == "Resultado") { ?>
							<div class="col-2">
								<p>
									<?php $candidato1->getCandidato(); ?>
								</p>
								<div class="label">
									<?php  
										$candidato1->exibirResultado();
									?>
								</div>
							</div>
							<div class="col-2">
								<p>
									<?php $candidato2->getCandidato(); ?>
								</p>
								<div class="label">
									<?php  
										$candidato2->exibirResultado();
										}
									?>
								</div>
							</div>
						</span>
						</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>